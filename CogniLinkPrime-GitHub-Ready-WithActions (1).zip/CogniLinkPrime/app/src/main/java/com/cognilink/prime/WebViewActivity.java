package com.cognilink.prime;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class WebViewActivity extends AppCompatActivity {
    
    private WebView webView;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefreshLayout;
    private SharedPreferences sharedPreferences;
    
    // URL الخادم - يمكن تغييرها حسب الحاجة
    private static final String SERVER_URL = "https://8080-ic7wmhq4sqfvztu1tgasv-2811ca38.manusvm.computer";
    private static final String FALLBACK_URL = "file:///android_asset/index.html";
    
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);
        
        // تهيئة المكونات
        webView = findViewById(R.id.webview);
        progressBar = findViewById(R.id.progress_bar);
        swipeRefreshLayout = findViewById(R.id.swipe_refresh);
        sharedPreferences = getSharedPreferences("CogniLinkPrefs", Context.MODE_PRIVATE);
        
        setupWebView();
        setupSwipeRefresh();
        loadApplication();
    }
    
    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        
        // تمكين JavaScript
        webSettings.setJavaScriptEnabled(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        
        // تحسين الأداء
        webSettings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setAppCacheEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setDomStorageEnabled(true);
        
        // دعم الملفات المحلية
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        
        // تحسين العرض
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        
        // دعم الوسائط
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        
        // إعداد User Agent مخصص
        String userAgent = webSettings.getUserAgentString();
        webSettings.setUserAgentString(userAgent + " CogniLinkPrime/1.0");
        
        // إضافة JavaScript Interface للتفاعل مع Android
        webView.addJavascriptInterface(new AndroidInterface(), "Android");
        
        // إعداد WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
            }
            
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
                
                // حفظ البيانات المحلية
                saveCurrentState();
            }
            
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
                
                // في حالة فشل تحميل الخادم، تحميل النسخة المحلية
                if (failingUrl.equals(SERVER_URL)) {
                    Toast.makeText(WebViewActivity.this, "تحميل النسخة المحفوظة محلياً", Toast.LENGTH_SHORT).show();
                    webView.loadUrl(FALLBACK_URL);
                }
            }
        });
        
        // إعداد WebChromeClient
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                progressBar.setProgress(newProgress);
            }
            
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                // طباعة رسائل وحدة التحكم للتطوير
                android.util.Log.d("WebView Console", consoleMessage.message() + 
                    " at " + consoleMessage.sourceId() + ":" + consoleMessage.lineNumber());
                return true;
            }
        });
        
        // إعداد DownloadListener
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, 
                                      String mimetype, long contentLength) {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimetype);
                request.addRequestHeader("User-Agent", userAgent);
                request.setDescription("تحميل ملف من CogniLink Prime");
                request.setTitle("CogniLink Prime Download");
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "CogniLinkPrime");
                
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                dm.enqueue(request);
                Toast.makeText(WebViewActivity.this, "بدء التحميل...", Toast.LENGTH_SHORT).show();
            }
        });
    }
    
    private void setupSwipeRefresh() {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                webView.reload();
            }
        });
        
        // تخصيص ألوان التحديث
        swipeRefreshLayout.setColorSchemeResources(
            android.R.color.holo_blue_bright,
            android.R.color.holo_green_light,
            android.R.color.holo_orange_light,
            android.R.color.holo_red_light
        );
    }
    
    private void loadApplication() {
        // محاولة تحميل الخادم أولاً
        if (NetworkUtils.isNetworkAvailable(this)) {
            webView.loadUrl(SERVER_URL);
        } else {
            // تحميل النسخة المحلية في حالة عدم وجود إنترنت
            Toast.makeText(this, "لا يوجد اتصال بالإنترنت - تحميل النسخة المحفوظة", Toast.LENGTH_SHORT).show();
            webView.loadUrl(FALLBACK_URL);
        }
    }
    
    private void saveCurrentState() {
        // حفظ حالة التطبيق الحالية
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("last_url", webView.getUrl());
        editor.putLong("last_access", System.currentTimeMillis());
        editor.apply();
        
        // تشغيل JavaScript لحفظ البيانات المحلية
        webView.evaluateJavascript(
            "(function() {" +
            "  if (typeof(Storage) !== 'undefined') {" +
            "    localStorage.setItem('app_last_backup', Date.now());" +
            "    return 'Backup saved';" +
            "  } else {" +
            "    return 'Storage not supported';" +
            "  }" +
            "})();", 
            null
        );
    }
    
    // JavaScript Interface للتفاعل مع Android
    public class AndroidInterface {
        @JavascriptInterface
        public void showToast(String message) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(WebViewActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            });
        }
        
        @JavascriptInterface
        public String getDeviceInfo() {
            return "Android " + android.os.Build.VERSION.RELEASE + 
                   " - " + android.os.Build.MODEL;
        }
        
        @JavascriptInterface
        public void saveData(String key, String value) {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(key, value);
            editor.apply();
        }
        
        @JavascriptInterface
        public String loadData(String key) {
            return sharedPreferences.getString(key, "");
        }
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // التعامل مع زر الرجوع
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
        saveCurrentState();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }
    
    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}

